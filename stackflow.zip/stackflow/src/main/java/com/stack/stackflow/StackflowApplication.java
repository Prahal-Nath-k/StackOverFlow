package com.stack.stackflow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StackflowApplication {

	public static void main(String[] args) {
		SpringApplication.run(StackflowApplication.class, args);
	}

}
