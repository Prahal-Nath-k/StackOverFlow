package com.stack.stackflow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StackflowApplicationTests {

	@Test
	void contextLoads() {
	}

}
